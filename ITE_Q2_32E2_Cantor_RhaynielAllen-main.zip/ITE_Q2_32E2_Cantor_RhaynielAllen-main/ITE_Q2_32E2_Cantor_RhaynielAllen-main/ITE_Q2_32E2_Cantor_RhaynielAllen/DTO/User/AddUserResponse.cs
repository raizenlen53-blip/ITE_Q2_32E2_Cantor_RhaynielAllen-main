﻿namespace ITE_Q2_32E2_Cantor_RhaynielAllen.DTO.User
{
    public class AddUserResponse
    {
        public string? Message { get; set; }
        public AddUserRequest? User { get; set; }
    }
}
