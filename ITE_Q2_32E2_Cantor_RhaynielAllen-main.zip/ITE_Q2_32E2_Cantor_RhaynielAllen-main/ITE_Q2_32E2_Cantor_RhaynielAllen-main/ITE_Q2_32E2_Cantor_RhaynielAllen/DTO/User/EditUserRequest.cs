﻿using System.ComponentModel.DataAnnotations;

namespace ITE_Q2_32E2_Cantor_RhaynielAllen.DTO.User
{
    public class EditUserRequest
    {
        public string? Name { get; set; }
        [EmailAddress]
        public string? Email { get; set; }
        [Required]
        public string? ID { get; set; }
    }
}
