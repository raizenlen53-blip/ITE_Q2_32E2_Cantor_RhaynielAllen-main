﻿namespace ITE_Q2_32E2_Cantor_RhaynielAllen.DTO.User
{
    public class EditUserResponse
    {
        public string? Message { get; set; }
        public EditUserRequest? User { get; set; }
    }
}
