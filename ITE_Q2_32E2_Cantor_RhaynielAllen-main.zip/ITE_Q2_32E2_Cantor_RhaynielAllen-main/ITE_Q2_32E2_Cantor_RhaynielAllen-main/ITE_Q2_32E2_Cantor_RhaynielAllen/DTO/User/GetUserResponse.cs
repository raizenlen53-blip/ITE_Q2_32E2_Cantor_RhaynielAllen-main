﻿namespace ITE_Q2_32E2_Cantor_RhaynielAllen.DTO.User
{
    public class GetUserResponse
    {
        public string? Message { get; set; }
    }
}
